#!/bin/bash

chapterFour() {
  echo "Group and User Management"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Add a Group"\
	    "Add a User"\
	    "Add a User to a Group"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 	"Add a Group")
    	 	echo "You have chosen to add a group, please enter a name."
    	 	read input
    	 	sudo groupadd $input
    	 	echo "You have added the $input group."
    	 	echo
    	 	break;;
    	 	
    	 	"Add a User")
    	 	echo "Please choose a username."
    	 	read input
    	 	sudo adduser $input
    	 	echo "Welcome $input."
    	 	echo
    	 	break;;
    	 	
    	 	"Add a User to a Group")
    	 	echo "Please select a group."
    	 	read input
    	 	echo "Please choose a user to add to the group."
    	 	read inputTwo
    	 	sudo usermod -a -G $input $inputTwo
    	 	echo "You have added $inputTwo to the group: $input."
    	 	echo
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterFive() {
  echo "Disk Management"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Create a Disk Partition"\
	    "Assign Disk Quota to a User"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 
    	 	"Create a Disk Partition")
    	 	echo "You are now attempting to add a disk partition."
    	 	echo "Please follow the instructions carefully to avoid loss of data."
    	 	sudo fdisk /dev/loop0
    	 	echo
    	 	break;;
    	 	
    	 	"Assign Disk Quota to a User")
    	 	echo "Notice: Not all Linux distrubutions come with Quota Installed. Use 'sudo apt install quota' if there are no quotas on your distrubiton. Additionally, you must configure the filesystem to accept Disk Quotas."
    	 	echo
    	 	echo "Please enter a username that will have a disk quota applied."
    	 	read input
    	 	sudo edquota -u $input
    	 	echo
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterSix() {
  echo "System and Boot Logs"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "View Kernel-related Messages"\
	    "View the Full Boot Log"\
	    "View the Last 50 Entries of the Boot Log"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 
    	 	"View Kernel-related Messages")
    	 	echo "You have chosen to view the system processes."
    	 	echo
    	 	sudo dmesg
    	 	echo
    	 	break;;
    	 	
    	 	"View the Full Boot Log")
    	 	echo "You have chosen to view the boot log."
    	 	echo
    	 	sudo journalctl -b
    	 	echo
    	 	break;;
    	 	
    	 	"View the Last 50 Entries of the Boot Log")
    	 	echo "You have chosen to view the boot log."
    	 	echo
    	 	sudo journalctl -n 50
    	 	echo
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterFourteen() {
  echo "Passwords and Security"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Update a User Password"\
	    "Password Requirements"\
	    "Permissions"\
	    "Encryption"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 	
    	 	"Update a User Password")
    	 	echo "Please enter the username."
    	 	read input1
    	 	echo "Please enter the new password."
    	 	read input2
    	 	echo $input1:$input2 | sudo chpasswd
    	 	echo "The password for $input1 has been changed to: $input2."
    	 	echo
    	 	break;;
    	 	
    	 	"Password Requirements")
    	 	echo "You have chosen to edit the Pluggable Authentication Modules..."
    	 	echo
    	 	sudo visudo -f /etc/pam.d/su-l
    	 	break;;
    	 	
    	 	"Permissions")
    	 	echo "You have chosen to edit Permissions..."
    	 	echo
    	 	sudo visudo -f sudoers
    	 	break;;
    	 	
    	 	"Encryption")
    	 	echo "You have chosen to generate an encryption key..."
    	 	echo "This will require GnuPG to be installed."
    	 	echo
    	 	sudo gpg --gen-key
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterNine() {
  echo "Scheduling and Processes"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Run a Scheduled Virus Scan -- Full with Active Log"\
	    "Run a Scheduled Virus Scan -- Chosen Directory"\
	    "Run a Scheduled Virus Scan -- Single File Scan"\
	    "View a List of All Current Processes"\
	    "Kill a Process by PID"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 	
    	 	"Run a Scheduled Virus Scan -- Full with Active Log")
    	 	echo "You have chosen to Schedule a Virus Scan."
    	 	echo "You will need to install clamav before you can run this portion of the script."
    	 	echo "Please enter a time in the following format:	
    	 	5 minutes
    	 	3 hours
    	 	1 day
    	 	4 weeks"
    	 	read input1
    	 	echo "You have selected to run a virus scan in $input1."
    	 	sudo at now + $input1 | sudo clamscan -r /
    	 	echo
    	 	break;;
    	 	
    	 	"Run a Scheduled Virus Scan -- Chosen Directory")
    	 	echo "You have chosen to Schedule a Virus Scan."
    	 	echo "You will need to install clamav before you can run this portion of the script."
    	 	echo "Please enter a time in the following format:	
    	 	5 min
    	 	3 hours
    	 	1 day
    	 	4 weeks"
    	 	read input1
    	 	echo "Please enter a directory -- use the following as an example:
    	 	/home"
    	 	read input2
    	 	echo "You have selected to scan $input2 in $input1."
    	 	sudo at now + $input1 | sudo clamscan $input2
    	 	echo
    	 	break;;
    	 	
    	 	"Run a Scheduled Virus Scan -- Single File Scan")
    	 	echo "You have chosen to Schedule a Virus Scan."
    	 	echo "You will need to install clamav before you can run this portion of the script."
    	 	echo "Please enter a time in the following format:	
    	 	5 min
    	 	3 hours
    	 	1 day
    	 	4 weeks"
    	 	read input1
    	 	echo "Please enter a filename -- use the following as an example:
    	 	zengage.sh"
    	 	read input2
    	 	echo "You have selected to scan $input2 in $input1."
    	 	sudo at now + $input1 | sudo clamscan $input2
    	 	echo
    	 	break;;
    	 	
    	 	"View a List of All Current Processes")
    	 	echo "You have chosen to View All Current Processes."
    	 	echo
    	 	sudo ps aux
    	 	echo
    	 	break;;
    	 	
    	 	"Kill a Process by PID")
    	 	echo "You have chosen to View All Current Processes."
    	 	echo
    	 	echo "Please input a process ID to be killed."
    	 	read input1
    	 	sudo kill -9 $input1
    	 	echo "$input1 has been successfully killed."
    	 	echo
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterTen() {
  echo "User Account Modification and Administration"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Update a User Description"\
	    "Change a User Login Name"\
	    "Lock a User Account"\
	    "Unlock a User Account"\
	    "View User Locks"\
	    "Delete a User Account"\
	    "Delete a User Account and Home Directory"\
	    "View the System Log Daemon Configuration"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 	
    	 	"Update a User Description")
    	 	echo "Please enter the username."
    	 	read input1
    	 	echo "Please enter a new description."
    	 	read input2
    	 	sudo usermod -c "$input2" $input1
    	 	echo "The description for $input1 has been changed to: $input2."
    	 	echo
    	 	break;; 
    	 	
    	 	"Change a User Login Name")
    	 	echo "Please enter the username."
    	 	read input1
    	 	echo "Please enter the new username."
    	 	read input2
    	 	sudo usermod -l $input2 $input1
    	 	echo "The login name for $input1 has been changed to: $input2."
    	 	echo
    	 	break;; 
    	 	
    	 	"View User Locks")
    	 	echo "Locks are indicated by a exclaimation point after the name."
    	 	sudo cat /etc/shadow
    	 	echo
    	 	break;;
    	 	
    	 	"Lock a User Account")
    	 	echo "Please enter the username."
    	 	read input1
    	 	sudo usermod -L $input1
    	 	echo "The user $input1 has been locked."
    	 	echo
    	 	break;;
    	 	
    	 	"Unlock a User Account")
    	 	echo "Please enter the username."
    	 	read input1
    	 	sudo usermod -U $input1
    	 	echo "The user $input1 has been unlocked."
    	 	echo
    	 	break;; 
    	 	
    	 	"Delete a User Account")
    	 	echo "Please enter the username."
    	 	read input1
    	 	sudo userdel $input1
    	 	echo "The user $input1 has been deleted."
    	 	echo
    	 	break;;
    	 	
    	 	"Delete a User Account and Home Directory")
    	 	echo "Please enter the username. This will delete the user account along with its home directory and content."
    	 	read input1
    	 	sudo userdel $input1
    	 	echo "The user $input1 and its content has been deleted."
    	 	echo
    	 	break;;
    	 	
    	 	"Delete a User Account")
    	 	echo "Please enter the username."
    	 	read input1
    	 	sudo userdel $input1
    	 	echo "The user $input1 has been deleted."
    	 	echo
    	 	break;;
    	 	
    	 	"View the System Log Daemon Configuration")
    	 	echo "You are now viewing the System Log Daemon."
    	 	echo
    	 	sudo cat /etc/rsyslog.conf
    	 	echo
    	 	break;;
    	 	
    	 	  

    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}

chapterEleven() {
  echo "File Compression"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "Install or Update File Compression Software"\
	    "Compress a Directory"\
	    "Compress a File"\
	    "Uncompress a File or Directory"\
	    "Exit Script"
	    
	    do
	    
    	 case $menuOption in
    	 	
    	 	"Install or Update File Compression Software")
    	 	echo "You have chosen to install or update file compression software."
    	 	echo
    	 	sudo apt-get -y install gzip
    	 	echo
    	 	echo "Gzip has been successfully updated/installed!"
    	 	break;;
    	 	
    	 	"Compress a Directory")
    	 	echo "You have chosen to compress a directory."
    	 	echo "Please choose a directory to compress."
    	 	read input1
    	 	sudo gzip -k -r $input1
    	 	echo
    	 	echo "$input1 has been successfully zipped!"
    	 	break;;
    	 	
    	 	"Compress a File")
    	 	echo "You have chosen to compress a file."
    	 	echo "Please choose a file to compress."
    	 	read input1
    	 	sudo gzip -k $input1
    	 	echo
    	 	echo "$input1 has been successfully zipped!"
    	 	break;;
    	 	
    	 	"Uncompress a File or Directory")
    	 	echo "You have chosen to uncompress a file or directory."
    	 	echo "Please choose a zipped file to uncompress."
    	 	read input1
    	 	sudo gunzip -d $input1
    	 	echo
    	 	echo "$input1 has been successfully unzipped!"
    	 	break;;
    	 		
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done
}
main() {

    echo "Welcome to the Zengage Education Services Script"
    echo "Please select a menu item"
    echo ""
    
    while true; do
    	select menuOption in\
	    "User and Group Management"\
	    "Disk Management"\
	    "System and Boot Logs"\
	    "Passwords and Security"\
	    "Scheduling and Processes"\
	    "User Account Modification and Administration"\
	    "File Compression"\
	    "List Users"\
	    "Exit Script"
     do
	    
    	 case $menuOption in
    	 
    	 
    	 	"User and Group Management")
    	 	chapterFour
    	 	break;;
    	 	
    	 	"Disk Management")
    	 	chapterFive
    	 	break;;
    	 	
    	 	"System and Boot Logs")
    	 	chapterSix
    	 	break;;
    	 	
    	 	"Passwords and Security")
    	 	chapterFourteen
    	 	break;;
    	 	
    	 	"Scheduling and Processes")
    	 	chapterNine
    	 	break;;
    	 	
    	 	"User Account Modification and Administration")
    	 	chapterTen
    	 	break;;
    	 	
    	 	"File Compression")
    	 	chapterEleven
    	 	break;;
    	 	
    	 	"List Users")
    	 	echo "You have chosen to list users -- Displaying the passwd file:"
    	 	echo
    	 	sudo cat /etc/passwd
    	 	break;;
    	 	
    	 	"Exit Script")
    	 	echo "You are exiting the script."
    	 	echo
    	 	break 2;;
    	 	
    	 	*)
    	 	echo "Please select a value from the menu."
    	 	break;;
    	 	
    	 esac
    done
    done


}

main "$@"
